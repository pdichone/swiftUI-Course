//
//  Food.swift
//  Starbux-B4-Go
//
//  Created by Paulo Dichone on 7/25/19.
//  Copyright © 2019 Paulo Dichone. All rights reserved.
//

import Foundation
import SwiftUI

struct Food: Identifiable {
    var id = UUID()
    var image = "bready"
}
