//
//  TopCard.swift
//  Starbux-B4-Go
//
//  Created by Paulo Dichone on 7/24/19. Updated on 10/02/10 for Xcode 11.2 Seed
//  Copyright © 2019 Paulo Dichone. All rights reserved.
//

import SwiftUI

struct TopCard: View {
    @Binding var showTopCard: Bool
    @Binding var foodData: [Food]
    
    var body: some View {
        ZStack {
            //Spacer()
             RoundedRectangle(cornerRadius: 45)
                .frame(width: 380, height: 270)
                .offset(x: -17)
                .foregroundColor(Color("cremeWhite"))
            
            RoundedRectangle(cornerRadius: 10)
                .frame(width: 100, height: 180)
                .offset(x: -165, y: 100)
                 .foregroundColor(Color("cremeWhite"))
            
            HStack {
                 Image("frappuccino")
                    .resizable()
                    .renderingMode(.original)
                    .frame(width: 150, height: 150)
                
                VStack {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(self.foodData, id: \.id) { item in
                                FoodItem(data: item)
//                                ZStack {
//                                     RoundedRectangle(cornerRadius: 30)
//                                        .frame(width: 90, height: 90)
//                                        .foregroundColor(Color("cremeDarker"))
//
//                                    Image("bready")
//                                        .resizable()
//                                        .frame(width: 70, height: 70)
//                                        .clipShape(Circle())
//                                            .overlay(Circle().stroke(Color("cremeWhite"), lineWidth: 1))
//                                }
                                
                            }
                        }
                    }//end scrollview
                    VStack(alignment: .leading) {
                        Text("Caramel Creme Frappuccino")
                            .fontWeight(.heavy)
                            .font(.title)
                            .foregroundColor(Color("darkGreen"))
                            .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                            .lineLimit(nil)
                    
                    }.padding(EdgeInsets(top: 0, leading: 10, bottom: 0, trailing: 10))
                }.frame(width: 240)
                    .padding(.trailing, 50)
            }.padding(.trailing, 3)
               
            
                
            
        }.animation(.spring())
            .onTapGesture {
                self.showTopCard.toggle()
        }
        .offset(x: self.showTopCard ? 0 : -300)
//            .tapAction {
//                self.showTopCard.toggle()
//        }
        //.offset(x: self.showTopCard ? 0 : -300)
    }
}

//#if DEBUG
//struct TopCard_Previews: PreviewProvider {
//    static var previews: some View {
//        TopCard()
//    }
//}
//#endif
