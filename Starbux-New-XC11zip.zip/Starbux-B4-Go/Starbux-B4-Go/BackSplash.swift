//
//  BackSplash.swift
//  Starbux-B4-Go
//
//  Created by Paulo Dichone on 7/24/19.
//  Copyright © 2019 Paulo Dichone. All rights reserved.
//

import SwiftUI

struct BackSplash: View {
    var body: some View {
        Rectangle()
            .fill(LinearGradient(gradient: Gradient(colors: [Color("lightGreen"), Color("lightGreen")]), startPoint: .top, endPoint: .bottom))
        .edgesIgnoringSafeArea(.all)
        
    }
}

#if DEBUG
struct BackSplash_Previews: PreviewProvider {
    static var previews: some View {
        BackSplash()
    }
}
#endif
