//
//  ContentView.swift
//  Starbux-B4-Go
//
//  Created by Paulo Dichone on 7/24/19.
//  Copyright © 2019 Paulo Dichone. All rights reserved.
//

import SwiftUI
let data = [
   Food( image: "muffinOne"),
   Food( image: "bready"),
   Food( image: "blueberry-muffin"),
   Food( image: "cakepop"),
   Food( image: "smokedBacon"),
   Food( image: "raspberryChoco")
   
]
struct ContentView: View {
    @State var showTopCard: Bool = true
    @State var foodData = data
    
    var body: some View {
        ZStack(alignment: .topLeading) {
             BackSplash()
              
              TopView()

            ZStack {
                TopCard(showTopCard: self.$showTopCard, foodData: self.$foodData)
                            
                BottomCard(showCard: self.$showTopCard)
            }
              
            
            
            
        }
        
    }
}

#if DEBUG
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
