//
//  FoodItem.swift
//  Starbux-B4-Go
//
//  Created by Paulo Dichone on 7/25/19.
//  Copyright © 2019 Paulo Dichone. All rights reserved.
//

import SwiftUI

struct FoodItem: View {
    var data: Food
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 30)
                .frame(width: 90, height: 90)
                .foregroundColor(Color("cremeDarker"))
            
            Image(data.image)
                .resizable()
                .frame(width: 70, height: 70)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color("cremeWhite"), lineWidth: 1))
        }
    }
}

#if DEBUG
struct FoodItem_Previews: PreviewProvider {
    static var previews: some View {
        FoodItem(data: Food( image: "bready"))
    }
}
#endif
