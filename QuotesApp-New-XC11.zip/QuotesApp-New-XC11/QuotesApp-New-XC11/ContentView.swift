import SwiftUI

struct ContentView: View {
    
    var quotes: [Quote]
    
//    var quotes: [Quote] = [
//
//              Quote(quote: "Whatever the mind of man can conceive...", name: "James Bond"),
//              Quote(quote: "Whatever the mind of man can conceive...", name: "James Bond"),
//              Quote(quote: "Whatever the mind of man can conceive...", name: "James Bond"),
//              Quote(quote: "Whatever the mind of man can conceive...", name: "James Bond"),
//              Quote(quote: "Whatever the mind of man can conceive...", name: "James Bond"),
//              Quote(quote: "Whatever the mind of man can conceive...", name: "James Bond"),
//              Quote(quote: "Whatever the mind of man can conceive...", name: "James Bond"),
//              Quote(quote: "Whatever the mind of man can conceive...", name: "James Bond"),
//              Quote(quote: "Whatever the mind of man can conceive...", name: "James Bond"),
//              Quote(quote: "Whatever the mind of man can conceive...", name: "James Bond")
//          ]
//
    var body: some View {
        VStack {
            CircleImage(imageName: "lilly")
                .frame(width: 160, height: 160)
                .padding(.top, 89)
                .padding(.bottom, 20)
            
            MainView(quotes: quotes)
            
            Spacer()
            
        }.background(Image("motivation_bg")
            .resizable()
            .scaledToFill()
            .edgesIgnoringSafeArea(.all))
        
    }
}





struct MainView: View {
    
    var quotes: [Quote]
     
//    let quotes = ["quote1", "quote2","quote1", "quote2", "quote1", "quote2", "quote1", "quote2","quote1", "quote2","quote1", "quote2","quote1", "quote2","quote1", "quote2"]
    
    
    var body: some View {
        VStack {
            
            HStack{
                Text("\(self.quotes.count) Quotes Available")
                    .font(.subheadline)
                    .italic()
                    .foregroundColor(.white)
            }
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(self.quotes, id: \.name) { quote in
                        VStack {
                           CircleImage(imageName: "lilly")
                            Text(#" "\#(quote.quote) " "#)
                                .font(.headline)
                                
                            
                            Divider()
                            
                            Text("By - \(quote.name)")
                            .italic()
                                .font(.custom("Helvetica neue", size: 14))
                        }.frame(width: 300, height: 300)
                            .foregroundColor(.gray)
                            .padding(.all, 4)
                            .background(Color.white)
                        .cornerRadius(13)
                        .overlay(Rectangle()
                            .fill(
                                LinearGradient(gradient: Gradient(colors: [.clear, .pink]), startPoint: .center, endPoint: .topLeading))
                            .clipped()
                            .shadow(radius: 8))
                        
                        
                        
                    }
                    
                }
            }
        }
    }
}

struct CircleImage: View {
    var imageName: String
    
    var body: some View {
        
            Image(imageName)
                .resizable()
                .clipShape(Circle())
                .overlay(Circle()
                    .stroke(Color.gray, lineWidth: 2))
                .shadow(radius: 10)
                .frame(width: 100, height:  100)
            
            
        
    }
}


//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
