//
//  NoDo.swift
//  NoDo-Improved-1-B4
//
//  Created by Paulo Dichone on 7/24/19.
//  Copyright © 2019 Paulo Dichone. All rights reserved.
//

import Foundation
import SwiftUI

let dateFormatter = DateFormatter()

struct NoDo:Identifiable, Decodable, Encodable {
    var id = UUID() //8sddzzyald
    var name: String = "Hello Item"
    var isDone: Bool = false
    private let dateAdded = Date()
    var dateText: String {
         dateFormatter.dateFormat = "MMM d yyyy, h:mm a"
        
        return dateFormatter.string(from: dateAdded)
    }
}
