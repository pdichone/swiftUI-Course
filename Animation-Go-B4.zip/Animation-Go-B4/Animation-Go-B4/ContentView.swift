//
//  ContentView.swift
//  Animation-Go-B4
//
//  Created by Paulo Dichone on 7/22/19.
//  Copyright © 2019 Paulo Dichone. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var show: Bool = false
    var body: some View {
        ZStack {
            
            CardView(show: self.$show)
           
            
            Text("Tap Me!")
        }.tapAction {
            self.show.toggle()
            print("Tap")
        }
    }
}




struct CardView: View {
    @Binding var show: Bool
    
    var body: some View {
        RoundedRectangle(cornerRadius: self.show ? 12 : 2)
            .shadow(radius: 12)
            .foregroundColor(self.show ? .pink : .red)
            .frame(width: 300 , height: 300)
            .animation(.spring())
            //.scaleEffect(self.show ? 0.3 : 0.2)
            .blur(radius: self.show ? 0 : 2)
            .rotation3DEffect(Angle(degrees: -24), axis: (x: 10, y: self.show ? 100 : 0, z: self.show ? -8 : 8))
            //.rotationEffect(Angle(degrees: self.show ? -12 : 12))
            .offset(x: self.show ? 0 : 300, y: self.show ? -140 : 0)
        
    }
}

#if DEBUG
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
