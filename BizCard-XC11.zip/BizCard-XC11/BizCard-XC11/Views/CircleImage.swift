//
//  CircleImage.swift
//  BizCard-XC11
//
//  Created by Paulo Dichone on 9/30/19.
//  Copyright © 2019 Paulo Dichone. All rights reserved.
//

import SwiftUI

struct CircleImage: View {
    var imageName: String
    
    var body: some View {
        Image(imageName)
            .resizable()
            .scaledToFit()
            .clipShape(Circle())
            .overlay(Circle()
                .stroke(Color.white, lineWidth: 3))
            .shadow(radius: 5)
    }
}
